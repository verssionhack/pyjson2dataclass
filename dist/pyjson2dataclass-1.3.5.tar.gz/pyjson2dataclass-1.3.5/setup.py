from setuptools import setup


setup(
        name='pyjson2dataclass',
        author='yinpeach',
        description='Parse json to dataclass',
        keywords=[
            'dataclass',
            'json',
            'yinpeach',
            'verssionhack'
            ],
        package_dir={
            'pyjson2dataclass': 'src',
            },
        )
